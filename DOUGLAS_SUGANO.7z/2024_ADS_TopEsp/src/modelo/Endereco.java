package modelo;
public class Endereco {
    
}
